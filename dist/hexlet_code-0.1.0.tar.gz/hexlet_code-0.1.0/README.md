<img onerror="this.src='https://github.com/github/docs/actions/workflows/main.yml/badge.svg';" src="https://github.com/Dmitryoff1/python-project-49/actions/workflows/hexlet-check.yml/badge.svg" loading="lazy">
«Игры разума» — набор из пяти консольных игр, построенных по принципу популярных мобильных приложений для прокачки мозга. Каждая игра задает вопросы, на которые нужно дать правильные ответы. После трех правильных ответов считается, что игра пройдена. Неправильные ответы завершают игру и предлагают пройти ее заново. Игры:

Калькулятор.
Прогрессия. (Поиск пропущенных чисел в последовательности чисел)
Определение четного числа
Определение наибольшего общего делителя
Определение простого числа

<a href="https://asciinema.org/a/ENgSvQV5BEyLiFDREkql9DAIA" target="_blank"><img src="https://asciinema.org/a/ENgSvQV5BEyLiFDREkql9DAIA.svg" /></a>
<a href="https://asciinema.org/a/sTBcjWFe7INs1jKAtDGj2iwcj" target="_blank"><img src="https://asciinema.org/a/sTBcjWFe7INs1jKAtDGj2iwcj.svg" /></a>
<a href="https://asciinema.org/a/TA2zBjoF9S6EaO356KnHcpx8h" target="_blank"><img src="https://asciinema.org/a/TA2zBjoF9S6EaO356KnHcpx8h.svg" /></a>
<a href="https://asciinema.org/a/vOBNlPPKQ4Or8zyyBZtsRJs0Y" target="_blank"><img src="https://asciinema.org/a/vOBNlPPKQ4Or8zyyBZtsRJs0Y.svg"/></a>
<a href="https://asciinema.org/a/smVMTd52Hry45GhLieeaboSI9" target="_blank"><img src="https://asciinema.org/a/smVMTd52Hry45GhLieeaboSI9.svg" /></a>
